import json
import math
import re
from pathlib import Path

import pymupdf
from PIL import Image, ImageDraw
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output' / 'elephant-walkthrough'
QA = ROOT / 'tmp' / 'pdfs' / 'elephant-walkthrough'
read = lambda n: json.loads((OUT / n).read_text(encoding='utf-8'))
vectors, retrieval = read('05-embeddings.json'), read('06-retrieval.json')
count = 0
for config, records in vectors['chunk_sets'].items():
    for record in records + vectors['queries']:
        assert len(record['vector']) == 384
        assert len(record['token_ids']) == len(record['token_pieces']) == record['model_token_count_including_special_tokens'] <= 512
        assert abs(math.sqrt(sum(x*x for x in record['vector'])) - 1) < 1e-5
        assert all(math.isfinite(x) for x in record['vector'])
    by_id = {r['chunk_id']: r for r in records}
    for query, result in zip(vectors['queries'], retrieval['chunk_sets'][config], strict=True):
        matches = result['all_ranked_matches']
        assert len(matches) == len(records)
        assert len({m['chunk_id'] for m in matches}) == len(records)
        assert [m['cosine_similarity'] for m in matches] == sorted((m['cosine_similarity'] for m in matches), reverse=True)
        for match in matches:
            record = by_id[match['chunk_id']]
            assert record['embedding_input'] == match['text']
            dot = sum(a*b for a,b in zip(record['vector'], query['vector'], strict=True))
            assert abs(dot - match['cosine_similarity']) < 1e-6
            count += 1

# Re-evaluate chunk offsets and all text coverage independently from the generator.
normalized, chunks = read('03-normalized.json'), read('04-chunks.json')
for group in chunks.values():
    for page in normalized['pages']:
        covered = set()
        for chunk in group['chunks']:
            if chunk['page_start'] != page['page_number']:
                continue
            assert page['raw_text'][chunk['char_start']:chunk['char_end']] == chunk['raw_text']
            start, end = chunk['metadata']['normalized_char_start'], chunk['metadata']['normalized_char_end']
            assert page['normalized_text'][start:end] == chunk['normalized_text']
            covered.update(range(start, end))
        assert all(i in covered for i,c in enumerate(page['normalized_text']) if not c.isspace())
assert read('01-validation.json')['staged_file_deleted_after_context']

guide = ROOT / 'docs' / 'phases guide' / 'phase-1' / 'elephant-processing-walkthrough.md'
for link in re.findall(r'\]\(([^)]+)\)', guide.read_text(encoding='utf-8')):
    if not link.startswith('https:'):
        assert (guide.parent / link).exists(), link

# Render the current PDFs, check bounds, and create one labelled QA contact sheet.
thumbnails = []
pdf_pages = {}
for path in (ROOT / 'output' / 'pdf').glob('elephant*.pdf'):
    with pymupdf.open(path) as pdf:
        pdf_pages[path.name] = len(pdf)
        for index, page in enumerate(pdf):
            for block in page.get_text('blocks'):
                assert block[0] >= 10 and block[1] >= 10
                assert block[2] <= page.rect.width - 10 and block[3] <= page.rect.height - 10, (path.name, index, block)
            pixmap = page.get_pixmap(matrix=pymupdf.Matrix(0.5, 0.5))
            image = Image.frombytes('RGB', [pixmap.width, pixmap.height], pixmap.samples)
            thumbnail = Image.new('RGB', (310, 445), 'white')
            ImageDraw.Draw(thumbnail).text((5, 4), f'{path.stem} / {index + 1}', fill='black')
            thumbnail.paste(image, (5, 23))
            thumbnails.append(thumbnail)
contact = Image.new('RGB', (310 * 4, 445 * math.ceil(len(thumbnails)/4)), '#dddddd')
for i, thumbnail in enumerate(thumbnails):
    contact.paste(thumbnail, ((i % 4) * 310, (i // 4) * 445))
contact.save(QA / 'contact-sheet.png')

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path=r'C:\Users\mohsi\AppData\Local\ms-playwright\chromium_headless_shell-1248\chrome-headless-shell-win64\chrome-headless-shell.exe')
    page = browser.new_page(viewport={'width': 1000, 'height': 850})
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.goto((QA / 'preview.html').as_uri())
    frame = page.frame_locator('iframe')
    frame.get_by_role('button', name='2 Markdown', exact=True).click()
    assert 'ELEPHANT FIELD NOTES' in frame.locator('#elephant-content').inner_text()
    frame.get_by_role('button', name='3 Normalized', exact=True).click()
    assert 'ELEPHANT FIELD NOTES' not in frame.locator('#elephant-content pre').first.inner_text()
    frame.get_by_role('button', name='4 Chunks', exact=True).click()
    frame.locator('#elephant-chunk').select_option('6')
    assert 'starts inside a word' in frame.locator('#elephant-content').inner_text()
    frame.get_by_role('button', name='5 Embeddings', exact=True).click()
    frame.get_by_text('All 384 embedding values', exact=False).click()
    assert '384 numbers' in frame.locator('#elephant-content').inner_text()
    frame.get_by_role('button', name='6 Retrieval', exact=True).click()
    frame.locator('#elephant-question').select_option('3')
    assert 'T06' in frame.locator('.result summary').first.inner_text()
    assert frame.locator('.result').count() == 7
    page.screenshot(path=str(QA / 'retrieval-desktop.png'), full_page=True)
    frame.locator('#elephant-config').select_option('1')
    assert frame.locator('.result').count() == 3
    frame.get_by_role('button', name='5 Embeddings', exact=True).click()
    assert frame.locator('#elephant-chunk option').count() == 3
    page.set_viewport_size({'width': 360, 'height': 800})
    frame.get_by_role('button', name='4 Chunks', exact=True).click()
    page.screenshot(path=str(QA / 'chunks-mobile.png'), full_page=True)
    iframe = page.frames[1]
    assert iframe.evaluate('document.documentElement.scrollWidth <= innerWidth'), 'Mobile horizontal overflow'
    assert not errors, errors
    browser.close()
summary = {'verified_score_calculations': count, 'chunk_sets': {k: len(v['chunks']) for k,v in chunks.items()}, 'pdf_pages': pdf_pages, 'browser_errors': errors, 'mobile_overflow': False, 'all_local_guide_links_exist': True}
(QA / 'verification.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
